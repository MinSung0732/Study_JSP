package Q_5;

public class Q5 {

}
