package Day9_Q9;

public class main {
	public static void main(String[] args) {
		kiosk k = new kiosk();
		k.run();
	}
}