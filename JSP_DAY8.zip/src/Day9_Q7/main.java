package Day9_Q7;

public class main {
	public static void main(String[] args) {
		int r[] = new int[2];
		String s[] = new String[2];
		
		r[0] = 1;
		r[1] = 2;
		s[0] = "고양이";
		s[1] = "개";
		
		System.out.println(r[0]);
		System.out.println(r[1]);
		System.out.println(s[0]);
		System.out.println(s[1]);
		
		
		
	}

}
