package Day9_Q7;

public class index {

}
