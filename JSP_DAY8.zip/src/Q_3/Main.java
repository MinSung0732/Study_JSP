package Q_3;

public class Main {
	public static void main(String[] args) {
		
		System.out.println(Q3.roll(100));
	}
}
