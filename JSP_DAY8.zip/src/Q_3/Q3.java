package Q_3;

public class Q3 {
	int n;
	
	static public int roll(int n) {
		int r = (int)(Math.random()*n+1);
		return r;
	}
	
	void x() {
		
	}
}
