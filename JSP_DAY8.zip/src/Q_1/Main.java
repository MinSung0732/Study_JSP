package Q_1;

public class Main {
	public static void main(String[] args) {
		Q1 rps = new Q1();
		rps.run();
	}
}