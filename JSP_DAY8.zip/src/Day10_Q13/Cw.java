package Day10_Q13;

public class Cw {
	public static void cw(String s) {
		System.out.println(s);
	}

}
