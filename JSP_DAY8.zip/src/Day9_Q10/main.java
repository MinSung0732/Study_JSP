package Day9_Q10;

public class main {
	public static void main(String[] args) {
		kiosk k = new kiosk();
		Display.title();
		k.run();
	}
}