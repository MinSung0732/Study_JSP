package Jsp_04;


public class JspQ1 {
	public static void main(String[] args) {
		System.out.println("헬로 키티 월드");
	}
}