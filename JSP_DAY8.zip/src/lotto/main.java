package lotto;

public class main {
	public static void main(String[] args) {
		lotto Lotto = new lotto();
		Lotto.lotto();
		
	}
}
