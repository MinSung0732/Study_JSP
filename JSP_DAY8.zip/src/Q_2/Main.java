package Q_2;

public class Main {
	public static void main(String[] args) {
		Q2 player = new Q2("우와",100,20,"엘프");
		
		player.info();
	}
}
